import json
import os
import openai
import filelock
import sys


def translate_questions(path, q_type, question_number):
    # Determine the file name based on q_type
    if q_type == "MC":
        file = "MCQ_Generated.txt"
    elif q_type == "DND":
        file = "DNDQ_Generated.txt"
    elif q_type == "FITB":
        file = "FITBQ_Generated.txt"
    else:
        raise ValueError(f"Unsupported q_type: {q_type}")

    # Path to the JSON file and lock file
    json_file_path = os.path.join(path, file)
    lock_file_path = json_file_path + '.lock'

    # Lock the JSON file
    lock = filelock.FileLock(lock_file_path)

    with lock:
        # Your existing code to translate questions
        print("Translating questions...")
        # Set up your OpenAI API key
        openai.api_key = "sk-proj-WweprkpRgauC0jqmYDCuT3BlbkFJ6Ind3a9429z8b0AYnyKa"

        def get_question_by_number(file_path, question_number):
            questions = []
            in_question = False
            column_stack = []
            current_question = []

            with open(file_path, 'r') as file:
                for line in file:
                    for index, char in enumerate(line):
                        if char == '{':
                            if not in_question:
                                in_question = True
                                column_stack.append(index)
                                current_question.append(char)
                            else:
                                current_question.append(char)
                        elif char == '}':
                            if in_question and column_stack and column_stack[-1] == index:
                                column_stack.pop()
                                current_question.append(char)
                                if not column_stack:
                                    in_question = False
                                    questions.append(''.join(current_question))
                                    current_question = []
                            else:
                                current_question.append(char)
                        elif in_question:
                            current_question.append(char)

            if 1 <= question_number <= len(questions):
                return questions[question_number - 1]
            else:
                return None

        def determine_question_type(file_path):
            if 'MC' in file_path:
                return 'MC'
            elif 'DND' in file_path:
                return 'DND'
            elif 'FITB' in file_path:
                return 'FITB'
            else:
                return 'Unknown'

        def translate_to_spanish(json_data):
            prompt = (
                    "translate the following JSON content to Spanish. Ensure that all keys and values, "
                    "including answer options, are translated. Leave all python keywords in english:\n\n" + json.dumps(json_data, indent=4)
            )
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a translator."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2048,
                temperature=0.5,
            )
            translation = response.choices[0].message['content'].strip()
            return json.loads(translation)

        def wrap_question_data(question_data, question_type):
            if question_type == 'MC':
                return {"multiplechoice": [question_data]}
            elif question_type == 'DND':
                return {"draganddrop": [question_data]}
            elif question_type == 'FITB':
                return {"completeblankspace": [question_data]}
            else:
                return question_data

        file_path = os.path.join(path, file)

        if not 1 <= question_number <= 10:
            raise ValueError("Question number must be between 1 and 10.")

        question = get_question_by_number(file_path, question_number)

        if question:
            question_type = determine_question_type(file_path)
            json_filename = f"Question{question_number}_{question_type}.json"
            save_path = os.path.join(path, json_filename)

            question_data = {
                "title": f"Question {question_number}",
                "question": json.loads(question)
            }

            # Translate the JSON data to Spanish
            translated_question_data = translate_to_spanish(question_data)

            # Wrap the translated JSON data with the appropriate outer shell
            wrapped_question_data = wrap_question_data(translated_question_data, question_type)

            # Save the wrapped translated JSON data
            with open(save_path, 'w') as json_file:
                json.dump(wrapped_question_data, json_file, indent=4)

            print(f"Translated and wrapped question {question_number} saved to {save_path}")
        else:
            print(f"Question {question_number} not found in the file.")

    print("Question translation completed.")


# Call the function with command-line arguments
if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise ValueError("Please provide the q_type and question_number arguments.")

    q_type = sys.argv[1]
    question_number = int(sys.argv[2])
    path = r'C:\Users\matth\PythonProject\Tasks\Pipeline Folder'

    translate_questions(path, q_type, question_number)
