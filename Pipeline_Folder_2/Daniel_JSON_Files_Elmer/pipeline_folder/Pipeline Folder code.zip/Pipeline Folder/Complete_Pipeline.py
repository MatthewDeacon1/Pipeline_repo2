import subprocess

# Initialize the question topic variable
question_topic = "if statements"

# Paths to the question generator scripts
scripts = [
    "MC_Question_Generator.py",
    "DND_Question_Generator.py",
    "FITB_Question_Generator.py"
]

# Run each question generator script
for script in scripts:
    script_path = f"C:\\Users\\matth\\PythonProject\\Tasks\\Pipeline Folder\\{script}"
    subprocess.run(["python", script_path, question_topic])

# Run the JSON Check.py script
subprocess.run(["python", "All_JSON_Check.py", question_topic])

# Run the Random Question Translator.py script
subprocess.run(["python", "Question_Translator.py", question_topic])
