import subprocess
import sys

# Set the q_type variable to either "MC", "DND"(Drag and drop), or "FITB" for question type
q_type = "FITB"  # Assuming you want to generate DND questions
# Set the translated_q_number variable to specify the question number to translate
translated_q_number = 2
# Set the question_topic variable
question_topic = "functions"

# Determine the appropriate question generator script based on q_type
if q_type == "MC":
    question_generator_script = "MC_Question_Generator.py"
elif q_type == "DND":
    question_generator_script = "DND_Question_Generator.py"
elif q_type == "FITB":
    question_generator_script = "FITB_Question_Generator.py"
else:
    raise ValueError(f"Unsupported q_type: {q_type}")

# Path to the question generator script
script_path = f"C:\\Users\\matth\\PythonProject\\Tasks\\Pipeline Folder\\{question_generator_script}"

# Run the appropriate question generator script with question_topic as an argument
subprocess.run(["python", script_path, question_topic])

# Run the JSON Check.py script with the q_type argument
subprocess.run(["python", "JSON_Check.py", q_type, question_topic])

# Run the Random Question Translator.py script after JSON Check.py has finished
subprocess.run(["python", "Random_Question_Translator.py", q_type, str(translated_q_number)])
