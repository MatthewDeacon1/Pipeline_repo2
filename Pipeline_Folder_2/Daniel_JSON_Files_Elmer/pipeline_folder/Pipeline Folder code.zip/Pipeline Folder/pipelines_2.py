import subprocess
import sys

def run_python_scripts(argument):
    try:
        # Run the first Python script
        print("Running All_JSON_Check.py")
        result1 = subprocess.run(['python', 'All_JSON_Check.py', argument], capture_output=True, text=True)
        print("Output of the first script:")
        print(result1.stdout)
        if result1.stderr:
            print("Error in the first script:", result1.stderr)
        
        # Run the second Python script
        print("Running Question_Translator.py")
        result2 = subprocess.run(['python', 'Question_Translator.py', argument], capture_output=True, text=True)
        print("\nOutput of the second script:")
        print(result2.stdout)
        if result2.stderr:
            print("Error in the second script:", result2.stderr)

    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running the scripts: {e}")

if __name__ == "__main__":
    # Check if the argument is provided
    if len(sys.argv) < 2:
        print("Usage: python run_pipeline.py 'if statements'")
        sys.exit(1)

    # Get the argument from command line input
    argument = sys.argv[1]

    # Run the Python scripts with the provided argument
    run_python_scripts(argument)
