import json
import filelock
import os
import subprocess
import sys

def JSON_check_step(path, file, question_topic):
    def is_valid_json(question):
        """Check if a string is valid JSON."""
        try:
            json.loads(question)
            return True
        except json.JSONDecodeError:
            return False

    def extract_questions(file_path):
        """Extract questions from a text file."""
        questions = []
        with open(file_path, 'r') as file:
            lines = file.readlines()

        current_question = ""
        in_question = False
        for line in lines:
            for idx, char in enumerate(line):
                if (char == '{') and not in_question:
                    in_question = True
                    current_question = char
                elif (char == '}') and in_question and (line[idx - 1] == '\n'):
                    current_question += char
                    questions.append(current_question.strip())
                    in_question = False
                    current_question = ""
                elif in_question:
                    current_question += char

        return questions

    def check_questions(file_path):
        """Check each question in the file for valid JSON format."""
        questions = extract_questions(file_path)
        results = []
        for question in questions:
            is_valid = is_valid_json(question)
            results.append(is_valid)
        return results

    # Path to the JSON file and lock file
    json_file_path = os.path.join(path, file)
    lock_file_path = json_file_path + '.lock'

    # Lock the JSON file
    lock = filelock.FileLock(lock_file_path)

    max_attempts = 5
    attempt = 0

    while attempt < max_attempts:
        with lock:
            # Determine which generator script to run based on the file name
            if file == "DNDQ_Generated.txt":
                question_generator_script = "DND_Question_Generator.py"
            elif file == "MCQ_Generated.txt":
                question_generator_script = "MC_Question_Generator.py"
            elif file == "FITBQ_Generated.txt":
                question_generator_script = "FITB_Question_Generator.py"
            else:
                raise ValueError("Unsupported file name.")

            # Run the appropriate question generator script with question_topic as an argument
            question_generator_script_path = os.path.join(path, question_generator_script)
            python_interpreter = sys.executable

            print(f"Running script at: {question_generator_script_path}")

            try:
                subprocess.run([python_interpreter, question_generator_script_path, question_topic], check=True, shell=True)
            except FileNotFoundError:
                print(f"File not found: {question_generator_script_path}")
                return False
            except subprocess.CalledProcessError as e:
                print(f"Error running script: {e}")
                return False

            print("Checking JSON file...")

            # Check the JSON file for valid questions
            results = check_questions(json_file_path)
            counter_true_q = sum(results)

            print("JSON Check completed.")
            if counter_true_q >= 10:
                return True

            attempt += 1
            print(f"Attempt {attempt} of {max_attempts}.")

    print("Exceeded maximum number of attempts.")
    return False

if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise ValueError("Please provide the q_type and question_topic arguments.")

    q_type = sys.argv[1]
    question_topic = sys.argv[2]

    if q_type == "MC":
        file = "MCQ_Generated.txt"
    elif q_type == "DND":
        file = "DNDQ_Generated.txt"
    elif q_type == "FITB":
        file = "FITBQ_Generated.txt"
    else:
        raise ValueError(f"Unsupported q_type: {q_type}")

    path = r"C:\Users\matth\PythonProject\Tasks\Pipeline Folder"

    everything_good = JSON_check_step(path, file, question_topic)

    print("Check if everything was good: " + str(everything_good))
