import openai
import sys

# Set up your OpenAI API key
api_key = "sk-proj-WweprkpRgauC0jqmYDCuT3BlbkFJ6Ind3a9429z8b0AYnyKa"
openai.api_key = api_key

if len(sys.argv) < 2:
    raise ValueError("Please provide the question_topic as an argument.")
question_topic = sys.argv[1]

# Print message before running the API request
print("Running API Question Generator")

# Define the system prompt
system_prompt = """
You are an expert Python question generator focused on creating high-quality questions of varying difficulty to teach students. "
"The user prompt will specify the type of question, relative difficulty level (1-10, where 1 is the easiest), and question topic. "
"Diversify the question subtypes or methods used within a particular question category. Ensure each part has only one unambiguous correct answer. "
"Maintain a high standard of question quality, ensuring clarity, precision, and proper grammar. The output for the multiple choice questions should be a JSON with the following format: "
'{
    "title": "Select the correct answer", 
    "blocks": [
        {
            "type": "info", 
            "text": "Text for the question"
            }
            ], 
    "answers": [
        {
            "text": "Choice1", 
            "correct": true}, 
        {
            "text": "Choice2", 
            "correct": false}, 
        {
            "text": "Choice3",
             "correct": false}, 
        {
            "text": "Choice4",
            "correct": false}
            ]
            }'
"""

# Define the user prompt
user_prompt = f"""
Create 10 multiple choice questions about {question_topic}. Where each multiple choice question increments by 1 in difficulty, going from 1 to 10. Respond with the questions formatted as JSON objects.
"""

# Make the API request
response = openai.ChatCompletion.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ],
    max_tokens=2048,
    n=1,
    temperature=0.5
)

# Get the API response
api_output = response.choices[0].message["content"].strip()

# Create a text file and export the API's output to that file
output_filename = "MCQ_Generated.txt"
with open(output_filename, "w") as file:
    file.write(api_output)

print(f"The API output has been written to {output_filename}.")